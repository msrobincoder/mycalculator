# mycalculator
My first calculator in Kotlin
This is a very basic calculator written in Kotlin.
Added +, -, and * buttons for addition, subtraction, and multiplication respectively.
